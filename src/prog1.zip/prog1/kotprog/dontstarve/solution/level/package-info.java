/**
 * A pályát leíró osztályokat tartalmazó package.
 */
package prog1.kotprog.dontstarve.solution.level;
