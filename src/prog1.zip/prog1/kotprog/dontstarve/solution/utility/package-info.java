/**
 * Egyéb segítő osztályokat tartalmazó package.
 */
package prog1.kotprog.dontstarve.solution.utility;
