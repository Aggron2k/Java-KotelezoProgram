/**
 * A programhoz készült annotációkat tartalmazó package.
 */
package prog1.kotprog.dontstarve.solution.annotations;
