package prog1.kotprog.dontstarve.solution.character;

import prog1.kotprog.dontstarve.solution.character.actions.Action;
import prog1.kotprog.dontstarve.solution.inventory.BaseInventory;
import prog1.kotprog.dontstarve.solution.utility.Position;

public class Character implements BaseCharacter {
    public Character() {
    }

    @Override
    public float getSpeed() {
        return 0;
    }

    @Override
    public float getHunger() {
        return 0;
    }

    @Override
    public float getHp() {
        return 0;
    }

    @Override
    public BaseInventory getInventory() {
        return null;
    }

    @Override
    public Position getCurrentPosition() {
        return null;
    }

    @Override
    public Action getLastAction() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }
}
